def train():
    import nltk
    from nltk.stem.lancaster import LancasterStemmer
    stemmer = LancasterStemmer()
    import pymongo
    import numpy
    import tflearn
    import tensorflow
    import random
    import json
    import pickle

    client = pymongo.MongoClient("mongodb+srv://admin1:K64Kugzbg7IxpdKc@cluster0-rdr8i.mongodb.net/test?retryWrites=true&w=majority")
    #db = client.test

    db=client.ChatBot
    data=db.Model.find_one()

    docs_x=[]
    docs_y=[]
    labels=[]
    words=[]

    for intent in data["intents"]:
        for pattern in intent["patterns"]:
            wrds = nltk.word_tokenize(pattern)
            words.extend(wrds)
            docs_x.append(wrds)
            docs_y.append(intent["tag"])

        if intent["tag"] not in labels:
            labels.append(intent["tag"])


    words = [stemmer.stem(w.lower()) for w in words if w != "?"]
    words = sorted(list(set(words)))
    labels = sorted(labels)

    training = []
    output = []

    out_empty = [0 for _ in range(len(labels))]

    for x, doc in enumerate(docs_x):

        bag = []

        wrds = [stemmer.stem(w.lower()) for w in doc]

        for w in words:
            if w in wrds:
                bag.append(1)
            else:
                bag.append(0)

        output_row = out_empty[:]
        output_row[labels.index(docs_y[x])] = 1

        training.append(bag)
        output.append(output_row)


    training = numpy.array(training)
    output = numpy.array(output)
    words=pickle.dumps(words)
    labels=pickle.dumps(labels)

    tensorflow.reset_default_graph()
    net = tflearn.input_data(shape=[None, len(training[0])])
    net = tflearn.fully_connected(net, 8)
    net = tflearn.fully_connected(net, 8)
    net = tflearn.fully_connected(net, len(output[0]), activation="softmax")
    net = tflearn.regression(net)

    model = tflearn.DNN(net)

    #try:
    #    model.load("model.tflearn")
    #except:
    model.fit(training, output, n_epoch=1000, batch_size=8, show_metric=True)
    model.save("model.tflearn")
    #chatbot_model=pickle.dumps(model)


    pickle_data=db.Pickle
    training=pickle.dumps(training)
    output=pickle.dumps(output)
    pickle_data.find_one_and_update(
        {"id_":"pickleWord"},
        {"$set":{"id_":"pickleWord","words":words}},upsert=True)
    pickle_data.find_one_and_update(
        {"id_":"pickleLabel"},
        {"$set" :{"id_":"pickleLabel", "labels":labels}}, upsert=True ) 
    pickle_data.find_one_and_update(
        {"id_":"pickleTrain"},
        {"$set":{"id_":"pickleTrain","training":training}},upsert=True
    )
    pickle_data.find_one_and_update(
        {"id_":"pickleOutput"},
        {"$set":{"id_":"pickleOutput","output":output}},upsert=True
    )
    #pickle_data.findOneandUpdate({"id_":"pickleModel"},
    #{$set :{"id_":"pickleModel","models":chatbot_model}},
    #{upsert=True})
  
