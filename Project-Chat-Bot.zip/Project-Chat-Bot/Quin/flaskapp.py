from flask import Flask, request,render_template,flash, redirect, url_for, session, request, logging
#from mainchat import *
import random
import mainchat
from profanityfilter import ProfanityFilter
import datetime
import time 
from flask_pymongo import pymongo
import bcrypt
from bson.objectid import ObjectId
from functools import wraps
import json
import remodel


def pfilter(userInput):
    pf = ProfanityFilter()
    output = pf.censor(userInput)
    return output

def automatedMsg():

    for i in range (2, 0 , -1):
        s = i
        print ("Are you still there")
        time.sleep(30)
    

app = Flask (__name__)
app.secret_key = 'secretkey'

user="admin1"
pasword="K64Kugzbg7IxpdKc"
client = pymongo.MongoClient("mongodb+srv://tester:tester101@cluster0-rdr8i.mongodb.net/test?retryWrites=true&w=majority")
db=client.ChatBot
col=db.User


@app.route("/")
def home():
    #automatedMsg()
    return render_template("index1.html")


@app.route("/get")
def get_response():
    userText = request.args.get('msg')
    prof = pfilter(userText)
    print(prof)
    if prof == True:
        response = "I understand you may be fustrated, but please refrain from using profanity"
    else:
        response = mainchat.response(userText)
    return response

@app.route('/login', methods=['GET', 'POST'])
def login():
    # Output message if something goes wrong...
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
            
        username = request.form['username']
        password = request.form['password']


        user=col.find_one({"username":username})
        hashPassword=user['password']
        if bcrypt.checkpw(password.encode("utf-8"), hashPassword):
         # Create session data, we can access this data in other routes
            session['loggedin'] = True
            session['id'] = user['id_']
            session['username'] = user['username']
            # Redirect to home page
            return redirect(url_for('adminPage'))
        else:
            # Account doesnt exist or username/password incorrect
            msg = 'Incorrect username/password!'

    return render_template('login.html', msg='')
@app.route('/login/logout')
def logout():
    # Remove session data, this will log the user out
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   # Redirect to login page
   return redirect(url_for('index1'))

def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'loggedin' in session:
            return f(*args, **kwargs)
        else:
            flash("You need to login first")
            return redirect(url_for('login'))

    return wrap

@app.route('/login/adminPage')
def adminPage():
    # Check if user is loggedin
    if 'loggedin' in session:
        # User is loggedin show them the home page
        return render_template('adminPage.html', username=session['username'])
    # User is not loggedin redirect to login page
    return redirect(url_for('login'))

@app.route('/login/UpdateForm', methods=['GET', 'POST'])
@login_required
def UpdateForm():
    

    client = pymongo.MongoClient("mongodb+srv://"+user+":"+pasword+"@cluster0-rdr8i.mongodb.net/test?retryWrites=true&w=majority")
    db=client.ChatBot
    coll=db.Model
    if request.method == 'POST' and 'tag' in request.form and 'pattern' in request.form and 'response':
        tag=request.form['tag']
        pattern=request.form['pattern']
        response=request.form['response']
        tag=tag.lower()
        up=coll.update_many( { "id_":"testIntents" , "intents.tag": tag },
        { "$push": {"intents.$.patterns":{"$each":[pattern]}}})
        rp=coll.update_many( { "id_":"testIntents" , "intents.tag": tag },
        { "$push": {"intents.$.responses":{"$each":[response]}}})
        if up.modified_count==1 and rp.modified_count==1:
            flash("Update made!","success")
        else:
            flash("Error update was not made please try again","danger")
    return render_template(('UpdateForm.html'))

@app.route('/login/uploadFile', methods=['GET', 'POST'])
@login_required
def uploadFile():
   

    if request.method=='POST' and 'file' in request.files:
        file=request.files['file']
        data=json.load(file)
        

        client = pymongo.MongoClient("mongodb+srv://"+user+":"+pasword+"@cluster0-rdr8i.mongodb.net/test?retryWrites=true&w=majority")
        db=client.ChatBot
        coll=db.Model
        coll.find_one_and_update(
        {'_id':ObjectId("5eb776aaa39cc3eb4ff62fa5")},
        {"$set":{"intents":data}}, upsert=True)
        flash("Intents file was updated", "success")

    else:
        flash("upload not created")
    return render_template('uploadFile.html')

@app.route('/Train')
@login_required
def Train():
    remodel.train()
    flash("Model Retrained!")
    return redirect(url_for('adminPage'))
  

if __name__ == "__main__":
    app.run()
