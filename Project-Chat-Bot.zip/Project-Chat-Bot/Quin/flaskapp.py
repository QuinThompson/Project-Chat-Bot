from flask import Flask, request,render_template,flash, redirect, url_for, session, request, logging
#from mainchat import *
import random
import mainchat
from profanityfilter import ProfanityFilter
import datetime
import time 

def pfilter(userInput):
    pf = ProfanityFilter()
    output = pf.censor(userInput)
    return output

def automatedMsg():

    for i in range (2, 0 , -1):
        s = i
        print ("Are you still there")
        time.sleep(30)
    

app = Flask (__name__)

@app.route("/")
def home():
    #automatedMsg()
    return render_template("index1.html")


@app.route("/get")
def get_response():
    userText = request.args.get('msg')
    prof = pfilter(userText)
    print(prof)
    if prof == True:
        response = "I understand you may be fustrated, but please refrain from using profanity"
    else:
        response = mainchat.response(userText)
    return response



if __name__ == "__main__":
    app.run()
