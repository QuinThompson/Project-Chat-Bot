import nltk
from nltk.stem.lancaster import LancasterStemmer
stemmer = LancasterStemmer()
import pymongo
import numpy
import pickle
import random
import json
import tflearn
import tensorflow
client = pymongo.MongoClient("mongodb+srv://admin1:K64Kugzbg7IxpdKc@cluster0-rdr8i.mongodb.net/test?retryWrites=true&w=majority")
db = client.ChatBot

pickle_file=db.Pickle
pf=pickle_file.find_one({"id_":"pickleWord"})
words=pf["words"]
words = pickle.loads(words)
pf=pickle_file.find_one({"id_":"pickleLabel"})
labels=pf["labels"]
labels = pickle.loads(labels)
pf=pickle_file.find_one({"id_":"pickleTrain"})
training=pf["training"]
training = pickle.loads(training)
pf=pickle_file.find_one({"id_":"pickleOutput"})
output=pf["output"]
output=pickle.loads(output)


tensorflow.reset_default_graph()
net = tflearn.input_data(shape=[None, len(training[0])])
net = tflearn.fully_connected(net, 8)
net = tflearn.fully_connected(net, 8)
net = tflearn.fully_connected(net, len(output[0]), activation="softmax")
net = tflearn.regression(net)

model = tflearn.DNN(net)

model.load('./model.tflearn')

get_data=db.Model
data=get_data.find_one()
def bag_of_words(s, words):
    bag = [0 for _ in range(len(words))]

    s_words = nltk.word_tokenize(s)
    s_words = [stemmer.stem(word.lower()) for word in s_words]

    for se in s_words:
        for i, w in enumerate(words):
            if w == se:
                bag[i] = 1
            
    return numpy.array(bag)

def chat():
    not_help = "Sorry"
    print("Start talking with the bot (type quit to stop)!")
    while True:
        inp = input("You: ")
        if inp.lower() == "quit":
            break

        results = model.predict([bag_of_words(inp, words)])

        results_index = numpy.argmax(results)
        tag = labels[results_index]

        for tg in data["intents"]:
            if tg['tag'] == tag:
                responses = tg['responses']

        if not_help in responses[0]: #to check if user was happy or not.
            print("Please go to this link")
        #print(responses[0])
        print(random.choice(responses))

def response(userText):
    results = model.predict([bag_of_words(userText, words)])
    results_index = numpy.argmax(results)
    tag = labels[results_index]
    for tg in data["intents"]:
        if tg['tag'] == tag:
            responses = tg['responses']
    return random.choice(responses)        

#chat()